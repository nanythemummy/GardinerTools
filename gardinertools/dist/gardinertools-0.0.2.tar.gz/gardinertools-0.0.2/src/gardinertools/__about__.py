# SPDX-FileCopyrightText: 2025-present Kea Johnston <keajohnston@uchicago.edu>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.2"
